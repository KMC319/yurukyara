﻿using UnityEngine;

namespace Zenject.Tests.Bindings.FromPrefabResource
{
    public class Bar : MonoBehaviour
    {
    }
}
